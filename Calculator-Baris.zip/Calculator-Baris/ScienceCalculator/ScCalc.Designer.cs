﻿namespace ScienceCalculator
{
    partial class ScCalc
    {

        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }


        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button14;
        internal System.Windows.Forms.Button btnSin;
        private System.Windows.Forms.GroupBox groupBox1;
        internal System.Windows.Forms.Button button24;
        internal System.Windows.Forms.Button btnInvSin;
        internal System.Windows.Forms.Button btnInvCos;
        internal System.Windows.Forms.Button btnInvTan;
        internal System.Windows.Forms.Button btnSinh;
        internal System.Windows.Forms.Button btnCosh;
        internal System.Windows.Forms.Button btnCos;
        internal System.Windows.Forms.Button btnTan;
        internal System.Windows.Forms.Button btnTruncate;
        internal System.Windows.Forms.Button btnFloor;
        internal System.Windows.Forms.Button btnCeil;
        internal System.Windows.Forms.Button btnRound;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;

    }
}


